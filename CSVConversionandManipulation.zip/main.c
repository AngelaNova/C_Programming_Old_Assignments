#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "convert_to_csv.h"
#include "read_csv.h"

void load_and_convert(const char* filename); 

void find_name(const char* csv_filename, const char* name){

	FILE* f;
	f=fopen(csv_filename, "rt");
	char buffer[100];
	char *line = NULL;
	int check=0;
	line=(char*) malloc(100*sizeof(char*)); 	

	while(fgets(buffer,100,f)!= NULL) { 
 	line = strstr(buffer,name); //is the name in the buffer?
	    	if(line!=NULL) {  
       			printf("The name %s was found with the following information:\n",name);
			printf("%s \n", line);
  			check++;
   		}
  	  	line = NULL;  //prepare line  for the next loop

	}
	if (check==0){ //checks if any occurence was found
		printf("The name, %s, was not found. \n ",name);
	}

	fclose(f);
	free(line);
}

void add_record(const char* csv_filename, const char* name, const int age, const char* city){

	FILE *f;
	f=fopen(csv_filename,"at");
	char array[70];
/*	char input[70];
	char num[3];
	itoa(age,num,10);
	//Creating the input to add to the file
	strcat(input,name);
	strcat(input,",");
	strcat(input,num);
	strcat(input,",");
	strcat(input,city);
*/	
	while(!(feof)){
		fgets(array,69,f);
	}
	fprintf(f,"%s, %d, %s \n", name,age,city);
	fclose(f);
}


void delete_record(const char* csv_filename, const char* name){

	FILE* f, *newF;
	f=fopen(csv_filename, "rt");
	newF=fopen("file", "wt");
	char *line;
	char *deleteLine=NULL;
	int count=0;
	deleteLine=(char*) malloc(100*sizeof(char*));
	line=(char*)malloc(100*sizeof(char*));
	fgets(line,100,f);
	while(!(feof(f))){
 		deleteLine= strstr(line,name); //is the name in the buffer/in this line?
	   	 if(deleteLine!=NULL){ //it is
			if(count!=0){//is it the first occurence?
				fprintf(newF,"%s",line); //no?  then print
			}  
       			count++;
   		}
		else{
			fprintf(newF,"%s",line);

		}
  	  	deleteLine = NULL;  //prepare line for the next loop
 		fgets(line,100,f);	
	}
	fclose(f);
	remove(csv_filename);
	rename("file",csv_filename);
	fclose(newF);
	free(deleteLine);
	free(line);

}


int main(){


//Question 1
//printf("First question (and second): \n");
load_and_convert("input.txt");

//Question 2
read_csv("output.csv");

//printf("Question 3.1 - find Maria :\n");
//Question 3.1
find_name("output.csv","Maria");

//printf("Question 3.1 -find Jason : \n");
find_name("output.csv","Jason"); //Jason doesn't exist

//printf("Question 3.2 - Add Jason : \n");
//Question 3.2
add_record("output.csv", "Jason",36,"Skookumchuk");
read_csv("output.csv"); //to print to the screen

//printf("Question 3.3 - Delete the first occurence of Maria: \n");
//Question 3.3
delete_record("output.csv","Maria");
read_csv("output.csv");//to print to the screen

return 0;



}
