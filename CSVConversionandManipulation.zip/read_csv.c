#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "read_csv.h"

void read_csv(const char* csv_filename){
	FILE *f;
	f=fopen(csv_filename,"rt");
	char* line;
	line=(char*)malloc(70*sizeof(char*));  //obtained error previously due to not having enough memory; added 70* to increase the size of the char*
	printf("\n");
	fgets(line,70,f);
	while(!(feof(f))){
		printf("%s \n",line);
		fgets(line,70,f);
	}
	fclose(f);
	free(line);}
