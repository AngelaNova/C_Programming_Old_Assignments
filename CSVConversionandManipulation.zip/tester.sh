#!/bin/bash

gcc dllstructure.c
./a.out
