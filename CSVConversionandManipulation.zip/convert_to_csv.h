
void load_and_convert(const char* filename);
