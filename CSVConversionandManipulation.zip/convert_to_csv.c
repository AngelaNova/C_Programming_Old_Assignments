#include <stdio.h>
#include <stdlib.h>
#include "convert_to_csv.h"

void load_and_convert(const char* filename){

	FILE *f,*newF;
	f=fopen(filename,"rf");
	newF=fopen("output.csv","wt");
	char names[1000],ages[1000],cities[1000];
	
	char c;
	int x,y,z;
	x=0;y=0;z=0;
	
	//save info
	fgets(names, 1000,f);
	fgets(ages, 1000,f);
	fgets(cities, 1000,f);
//	c=names[x];
	//Adding info
	while(c!='\n'){
		c=names[x];
		while (c!=' '&& c!='\n'){
			fputc(c,newF);		//adds the name
//			printf("%c",c);
			c=names[x+1];
			x++;
		}

		fputc(',',newF);
		fputc(' ',newF);
//		printf(" ");
		c=ages[y];
		while (c!=' '&& c!='\n'){
			fputc(c,newF);	//adds the age
//			printf("%c",c);
			c=ages[y+1];
			y++;
		}
		
		fputc(',',newF);
		fputc(' ',newF);
//		printf(" ");
		c=cities[z];
		while (c!=' '&& c!='\n'){
			fputc(c,newF);		//adds the city
//			printf("%c",c);
			c=cities[z+1];
			z++;
		}
//		printf("\n");
		fputc('\n',newF);
		x++;y++;z++;
	}

	
	fclose(f);
	fclose(newF);
}