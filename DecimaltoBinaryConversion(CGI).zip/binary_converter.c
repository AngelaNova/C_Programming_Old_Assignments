#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void convertToBinary(int num);

void main(){
	int unsigned num;
	char* env=NULL;
	char string[5];
	env=getenv("QUERY_STRING");//String name=$$$$$
//	l=strlen(env);
//	char* number;
//	strcmp(env,number+5);
	sscanf(env,"%*[^0-9]%d",&num); //get a number	
//	num=atoi(number);
	printf("Content-Type:text/html\n\n");  //CGI output tag
	printf("<html>");
//	printf("This is my QUERY_STRING: ...%s...</br>",env);
	printf("<h2>Convert Decimal to binary</h2>");
	printf("<b>The decimal number obtained from the user is: %u </b> </br></br>",num);
	printf("<body>");
	printf("<b> The binary number is: <b>");
	if(num==0){
	printf(" 0");
	}
	else{
	convertToBinary(num);
	}
	printf("</br>");
	printf("</body>");
	printf("</html>");
	free(env);
}
	
void convertToBinary(int num){
	int i;
	int binaryNum[1000];
	i=0;
	while(num>0){
		binaryNum[i]=num%2;
		num=num/2;
		i++;
		}

	//print 
	for (int j=i-1; j>=0;j--){

		printf("%i", binaryNum[j]);
	}

	printf("\n");
}

/*
}

int main(void){

	FILE *f=fopen("data.txt", "r");
	int ch;
*/

//	printf("Content-Type:text/html\n\n");  //CGI output tag
//	printf("<html>");
/*
	if (f==NULL){

		printf("<head><title>ERROR</title></head>");
		printf("<body><p>Unable to pen file!</p></body>");
	}
	else {
		while((ch=fgetc(f))!=EOF)putchar(ch);
		fclose(f);
	}

	printf("</html>");

	return 0;
}
*/

